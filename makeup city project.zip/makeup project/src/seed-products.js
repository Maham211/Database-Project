module.exports = [
  {
    "name": "Pro Gold BB Cream",
    "brand": "MAC",
    "price": 14.39,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/1.jpg",
    "stock": 23
  },
  {
    "name": "Feather Nude Glow Stick",
    "brand": "Maybelline",
    "price": 8.57,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/2.jpg",
    "stock": 37
  },
  {
    "name": "Velvet Bronze Illuminator",
    "brand": "Rare Beauty",
    "price": 44.94,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/3.jpg",
    "stock": 99
  },
  {
    "name": "Satin Plum Cream Blush",
    "brand": "Fenty Beauty",
    "price": 49.89,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/4.jpg",
    "stock": 10
  },
  {
    "name": "Pro Bronze Blush",
    "brand": "Huda Beauty",
    "price": 57.72,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/6.jpg",
    "stock": 53
  },
  {
    "name": "Glow Pink CC Cream",
    "brand": "NYX",
    "price": 38.99,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/5.jpg",
    "stock": 113
  },
  {
    "name": "Glow Cherry Brow Gel",
    "brand": "NARS",
    "price": 36.25,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/7.jpg",
    "stock": 116
  },
  {
    "name": "Ultra Cherry Cream Shadow",
    "brand": "Rare Beauty",
    "price": 9.42,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/8.jpg",
    "stock": 39
  },
  {
    "name": "Soft Taupe Foundation",
    "brand": "Est\u00e9e Lauder",
    "price": 21.72,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/9.jpg",
    "stock": 91
  },
  {
    "name": "Dew Plum Moisturizer",
    "brand": "Huda Beauty",
    "price": 44.19,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 97
  },
  {
    "name": "Radiant Pearl BB Cream",
    "brand": "Rare Beauty",
    "price": 31.49,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 44
  },
  {
    "name": "Cloud Gold Highlighter",
    "brand": "Fenty Beauty",
    "price": 50.55,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 113
  },
  {
    "name": "Hydra Sunset Blush",
    "brand": "Charlotte Tilbury",
    "price": 53.44,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 50
  },
  {
    "name": "Satin Plum Brow Pencil",
    "brand": "NYX",
    "price": 14.39,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 105
  },
  {
    "name": "Feather Sunset Glow Stick",
    "brand": "Charlotte Tilbury",
    "price": 28.16,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 38
  },
  {
    "name": "Hydra Mocha Highlighter",
    "brand": "Dior",
    "price": 15.09,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 30
  },
  {
    "name": "Hydra Taupe Blush Duo",
    "brand": "Rare Beauty",
    "price": 38.57,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 69
  },
  {
    "name": "Velvet Mocha Fixing Mist",
    "brand": "NARS",
    "price": 43.12,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 78
  },
  {
    "name": "Air Pearl Single Shadow",
    "brand": "Maybelline",
    "price": 31.04,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 102
  },
  {
    "name": "Radiant Mocha Fixing Mist",
    "brand": "NARS",
    "price": 53.13,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 48
  },
  {
    "name": "Ultra Pink Highlighter",
    "brand": "Rare Beauty",
    "price": 47.4,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 79
  },
  {
    "name": "Cloud Rose Lip Stain",
    "brand": "Rare Beauty",
    "price": 12.92,
    "category": "lipstick",
    "description": "High pigment, smooth glide, all-day confidence.",
    "image": "/assets/img/lipstick.svg",
    "stock": 56
  },
  {
    "name": "Soft Cherry Grip Primer",
    "brand": "MAC",
    "price": 11.53,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 72
  },
  {
    "name": "Matte Sand Highlighter",
    "brand": "Clinique",
    "price": 57.17,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 31
  },
  {
    "name": "Iconic Bronze Glow Stick",
    "brand": "Est\u00e9e Lauder",
    "price": 56.22,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 106
  },
  {
    "name": "Air Pink Pore Filler",
    "brand": "CeraVe",
    "price": 30.21,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 76
  },
  {
    "name": "Soft Cocoa Foundation",
    "brand": "Fenty Beauty",
    "price": 8.1,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 80
  },
  {
    "name": "Hydra Nude Grip Primer",
    "brand": "MAC",
    "price": 19.12,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 14
  },
  {
    "name": "Soft Sand CC Cream",
    "brand": "NARS",
    "price": 18.34,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 26
  },
  {
    "name": "Pure Bronze Brow Gel",
    "brand": "Fenty Beauty",
    "price": 11.99,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 94
  },
  {
    "name": "Studio Nude Single Shadow",
    "brand": "NYX",
    "price": 42.68,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 92
  },
  {
    "name": "Cloud Gold Lipstick",
    "brand": "NYX",
    "price": 17.14,
    "category": "lipstick",
    "description": "High pigment, smooth glide, all-day confidence.",
    "image": "/assets/img/lipstick.svg",
    "stock": 78
  },
  {
    "name": "Radiant Ivory Serum",
    "brand": "NYX",
    "price": 20.23,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 19
  },
  {
    "name": "Silky Espresso Illuminator",
    "brand": "Maybelline",
    "price": 51.3,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 21
  },
  {
    "name": "Pure Bronze Sunscreen",
    "brand": "NYX",
    "price": 52.82,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 17
  },
  {
    "name": "Luxe Ivory Blush Duo",
    "brand": "MAC",
    "price": 22.11,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 99
  },
  {
    "name": "Pure Bronze Highlighter",
    "brand": "The Ordinary",
    "price": 22.72,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 17
  },
  {
    "name": "Cloud Nude Highlighter",
    "brand": "MAC",
    "price": 37.95,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 74
  },
  {
    "name": "Crystal Pearl Cleanser",
    "brand": "MAC",
    "price": 10.62,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 18
  },
  {
    "name": "Glow Gold Grip Primer",
    "brand": "NYX",
    "price": 37.67,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 15
  },
  {
    "name": "Feather Plum CC Cream",
    "brand": "NYX",
    "price": 17.82,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 101
  },
  {
    "name": "Luxe Coral Primer",
    "brand": "Charlotte Tilbury",
    "price": 31.22,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 106
  },
  {
    "name": "Iconic Mocha Lip Balm",
    "brand": "Dior",
    "price": 10.87,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 37
  },
  {
    "name": "Dew Gold Setting Spray",
    "brand": "L'Or\u00e9al",
    "price": 26.57,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 30
  },
  {
    "name": "Air Caramel Illuminator",
    "brand": "CeraVe",
    "price": 7.4,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 114
  },
  {
    "name": "Glow Plum Setting Spray",
    "brand": "Kylie Cosmetics",
    "price": 13.11,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 23
  },
  {
    "name": "Pro Lilac Glow Stick",
    "brand": "L'Or\u00e9al",
    "price": 18.15,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 53
  },
  {
    "name": "Pure Nude Setting Powder",
    "brand": "NARS",
    "price": 11.88,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 64
  },
  {
    "name": "Cloud Plum Liquid Lip",
    "brand": "MAC",
    "price": 15.55,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 66
  },
  {
    "name": "Velvet Cherry Blush",
    "brand": "NARS",
    "price": 57.08,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 98
  },
  {
    "name": "Dew Espresso Illuminator",
    "brand": "MAC",
    "price": 14.84,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 26
  },
  {
    "name": "Silky Bronze Setting Powder",
    "brand": "Huda Beauty",
    "price": 43.14,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 95
  },
  {
    "name": "Bloom Lilac Single Shadow",
    "brand": "Clinique",
    "price": 46.71,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 40
  },
  {
    "name": "Studio Pearl Cleanser",
    "brand": "Kylie Cosmetics",
    "price": 46.03,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 52
  },
  {
    "name": "Radiant Mocha Grip Primer",
    "brand": "Charlotte Tilbury",
    "price": 27.26,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 14
  },
  {
    "name": "Satin Coral Pore Filler",
    "brand": "Fenty Beauty",
    "price": 50.48,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 39
  },
  {
    "name": "Ultra Cocoa Lip Stain",
    "brand": "The Ordinary",
    "price": 21.76,
    "category": "lipstick",
    "description": "High pigment, smooth glide, all-day confidence.",
    "image": "/assets/img/lipstick.svg",
    "stock": 18
  },
  {
    "name": "Crystal Espresso Single Shadow",
    "brand": "The Ordinary",
    "price": 24.54,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 13
  },
  {
    "name": "Feather Nude Setting Powder",
    "brand": "L'Or\u00e9al",
    "price": 12.74,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 65
  },
  {
    "name": "Iconic Mocha Cream Shadow",
    "brand": "NYX",
    "price": 27.41,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 83
  },
  {
    "name": "Studio Caramel Setting Spray",
    "brand": "MAC",
    "price": 56.05,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 78
  },
  {
    "name": "Studio Cocoa Primer",
    "brand": "Huda Beauty",
    "price": 40.02,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 94
  },
  {
    "name": "Air Berry Fixing Mist",
    "brand": "NARS",
    "price": 24.28,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 99
  },
  {
    "name": "Ultra Taupe Glow Stick",
    "brand": "L'Or\u00e9al",
    "price": 42.89,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 32
  },
  {
    "name": "Bloom Coral Setting Spray",
    "brand": "NYX",
    "price": 22.2,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 65
  },
  {
    "name": "Satin Bronze Single Shadow",
    "brand": "Dior",
    "price": 34.08,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 111
  },
  {
    "name": "Hydra Caramel Serum",
    "brand": "The Ordinary",
    "price": 42.17,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 89
  },
  {
    "name": "Soft Gold CC Cream",
    "brand": "Est\u00e9e Lauder",
    "price": 49.74,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 28
  },
  {
    "name": "Pure Cherry Lip Balm",
    "brand": "Fenty Beauty",
    "price": 31.13,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 90
  },
  {
    "name": "Luxe Taupe Pore Filler",
    "brand": "CeraVe",
    "price": 19.92,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 93
  },
  {
    "name": "Glow Gold Lip Stain",
    "brand": "Kylie Cosmetics",
    "price": 16.31,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 99
  },
  {
    "name": "Bloom Mocha Brow Pencil",
    "brand": "MAC",
    "price": 31.18,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 112
  },
  {
    "name": "Iconic Ivory Glow Stick",
    "brand": "NARS",
    "price": 39.46,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 102
  },
  {
    "name": "Bloom Pearl Blush Duo",
    "brand": "Est\u00e9e Lauder",
    "price": 46.4,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 70
  },
  {
    "name": "Soft Plum Fixing Mist",
    "brand": "Clinique",
    "price": 47.58,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 76
  },
  {
    "name": "Satin Coral Primer",
    "brand": "Charlotte Tilbury",
    "price": 19.42,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 52
  },
  {
    "name": "Matte Gold Highlighter",
    "brand": "Maybelline",
    "price": 27.29,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 29
  },
  {
    "name": "Studio Cocoa Pore Filler",
    "brand": "Maybelline",
    "price": 35.75,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 63
  },
  {
    "name": "Studio Sunset Pore Filler",
    "brand": "Est\u00e9e Lauder",
    "price": 57.13,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 12
  },
  {
    "name": "Velvet Coral Blush Duo",
    "brand": "Dior",
    "price": 46.92,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 119
  },
  {
    "name": "Bloom Gold Illuminator",
    "brand": "CeraVe",
    "price": 32.87,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 44
  },
  {
    "name": "Luxe Taupe Brow Gel",
    "brand": "MAC",
    "price": 45.37,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 117
  },
  {
    "name": "Bloom Taupe Cleanser",
    "brand": "Rare Beauty",
    "price": 38.36,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 94
  },
  {
    "name": "Studio Ivory BB Cream",
    "brand": "The Ordinary",
    "price": 16.62,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 43
  },
  {
    "name": "Satin Cocoa Single Shadow",
    "brand": "Fenty Beauty",
    "price": 47.34,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 58
  },
  {
    "name": "Hydra Rose Blush Duo",
    "brand": "Charlotte Tilbury",
    "price": 46.69,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 16
  },
  {
    "name": "Hydra Nude Grip Primer",
    "brand": "The Ordinary",
    "price": 46.96,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 41
  },
  {
    "name": "Matte Honey Liquid Lip",
    "brand": "Rare Beauty",
    "price": 32.09,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 24
  },
  {
    "name": "Pro Pearl Pore Filler",
    "brand": "Dior",
    "price": 39.1,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 105
  },
  {
    "name": "Radiant Mocha CC Cream",
    "brand": "Clinique",
    "price": 37.66,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 49
  },
  {
    "name": "Ultra Sunset Blush",
    "brand": "NYX",
    "price": 43.59,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 90
  },
  {
    "name": "Air Sunset Foundation",
    "brand": "CeraVe",
    "price": 48.47,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 54
  },
  {
    "name": "Dew Caramel Blush",
    "brand": "The Ordinary",
    "price": 41.31,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 11
  },
  {
    "name": "Studio Ivory Brow Gel",
    "brand": "Maybelline",
    "price": 44.48,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 65
  },
  {
    "name": "Pro Espresso Illuminator",
    "brand": "The Ordinary",
    "price": 48.05,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 69
  },
  {
    "name": "Soft Plum Setting Spray",
    "brand": "Huda Beauty",
    "price": 53.72,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 41
  },
  {
    "name": "Velvet Cocoa Blush Duo",
    "brand": "Huda Beauty",
    "price": 16.63,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 37
  },
  {
    "name": "Pro Plum Fixing Mist",
    "brand": "Huda Beauty",
    "price": 36.45,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 76
  },
  {
    "name": "Studio Espresso Tinted Moisturizer",
    "brand": "Fenty Beauty",
    "price": 47.17,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 98
  },
  {
    "name": "Velvet Coral Brow Pencil",
    "brand": "Dior",
    "price": 18.73,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 98
  },
  {
    "name": "Feather Sand Setting Powder",
    "brand": "The Ordinary",
    "price": 36.32,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 54
  },
  {
    "name": "Dew Ivory Illuminator",
    "brand": "Huda Beauty",
    "price": 21.35,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 42
  },
  {
    "name": "Ultra Mocha CC Cream",
    "brand": "CeraVe",
    "price": 46.36,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 107
  },
  {
    "name": "Ultra Sand Exfoliant",
    "brand": "Fenty Beauty",
    "price": 21.64,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 85
  },
  {
    "name": "Ultra Gold Setting Powder",
    "brand": "Maybelline",
    "price": 26.12,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 48
  },
  {
    "name": "Pro Nude Highlighter",
    "brand": "L'Or\u00e9al",
    "price": 36.32,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 99
  },
  {
    "name": "Velvet Coral Brow Kit",
    "brand": "Maybelline",
    "price": 31.87,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 66
  },
  {
    "name": "Pro Mocha Sunscreen",
    "brand": "MAC",
    "price": 50.56,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 61
  },
  {
    "name": "Silky Honey BB Cream",
    "brand": "Rare Beauty",
    "price": 49.98,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 48
  },
  {
    "name": "Bloom Lilac Pore Filler",
    "brand": "Maybelline",
    "price": 38.58,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 89
  },
  {
    "name": "Satin Coral Glow Stick",
    "brand": "NYX",
    "price": 52.58,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 64
  },
  {
    "name": "Glow Bronze Liquid Lip",
    "brand": "Rare Beauty",
    "price": 21.02,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 20
  },
  {
    "name": "Bloom Pearl Primer",
    "brand": "L'Or\u00e9al",
    "price": 7.13,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 67
  },
  {
    "name": "Silky Coral Brow Pencil",
    "brand": "Charlotte Tilbury",
    "price": 44.46,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 99
  },
  {
    "name": "Soft Sunset CC Cream",
    "brand": "The Ordinary",
    "price": 42.03,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 35
  },
  {
    "name": "Soft Plum BB Cream",
    "brand": "NARS",
    "price": 50.8,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 19
  },
  {
    "name": "Air Sunset Toner",
    "brand": "Clinique",
    "price": 55.81,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 66
  },
  {
    "name": "Air Taupe Brow Kit",
    "brand": "CeraVe",
    "price": 56.95,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 74
  },
  {
    "name": "Hydra Nude Brow Kit",
    "brand": "Dior",
    "price": 54.13,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 104
  },
  {
    "name": "Hydra Sunset Setting Spray",
    "brand": "MAC",
    "price": 38.11,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 12
  },
  {
    "name": "Silky Sand Setting Spray",
    "brand": "Rare Beauty",
    "price": 34.5,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 66
  },
  {
    "name": "Studio Sand Exfoliant",
    "brand": "Rare Beauty",
    "price": 58.35,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 70
  },
  {
    "name": "Cloud Mocha Cream Blush",
    "brand": "Huda Beauty",
    "price": 52.45,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 52
  },
  {
    "name": "Luxe Nude Brow Kit",
    "brand": "Charlotte Tilbury",
    "price": 31.1,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 50
  },
  {
    "name": "Luxe Rose Cream Shadow",
    "brand": "Maybelline",
    "price": 41.85,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 79
  },
  {
    "name": "Ultra Pink Cream Blush",
    "brand": "MAC",
    "price": 39.99,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 73
  },
  {
    "name": "Silky Plum Brow Pencil",
    "brand": "Clinique",
    "price": 36.1,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 46
  },
  {
    "name": "Velvet Lilac Brow Kit",
    "brand": "Maybelline",
    "price": 49.35,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 100
  },
  {
    "name": "Velvet Berry Fixing Mist",
    "brand": "NARS",
    "price": 11.93,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 117
  },
  {
    "name": "Matte Coral Brow Gel",
    "brand": "Maybelline",
    "price": 33.96,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 44
  },
  {
    "name": "Soft Espresso Brow Gel",
    "brand": "Dior",
    "price": 14.66,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 34
  },
  {
    "name": "Matte Plum Highlighter",
    "brand": "CeraVe",
    "price": 47.94,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 119
  },
  {
    "name": "Crystal Rose Single Shadow",
    "brand": "Kylie Cosmetics",
    "price": 21.98,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 48
  },
  {
    "name": "Matte Espresso Brow Gel",
    "brand": "Est\u00e9e Lauder",
    "price": 32.66,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 52
  },
  {
    "name": "Satin Bronze Glow Stick",
    "brand": "NYX",
    "price": 58.97,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 40
  },
  {
    "name": "Studio Cocoa Blush",
    "brand": "Fenty Beauty",
    "price": 46.46,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 100
  },
  {
    "name": "Matte Nude Blush Duo",
    "brand": "The Ordinary",
    "price": 13.68,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 85
  },
  {
    "name": "Satin Caramel Foundation",
    "brand": "Est\u00e9e Lauder",
    "price": 55.24,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 11
  },
  {
    "name": "Matte Sand Cleanser",
    "brand": "NYX",
    "price": 48.41,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 43
  },
  {
    "name": "Hydra Espresso Blush Duo",
    "brand": "The Ordinary",
    "price": 27.13,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 50
  },
  {
    "name": "Bloom Lilac Brow Pencil",
    "brand": "Est\u00e9e Lauder",
    "price": 10.62,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 90
  },
  {
    "name": "Hydra Mocha Setting Powder",
    "brand": "Fenty Beauty",
    "price": 47.29,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 100
  },
  {
    "name": "Air Nude Brow Pencil",
    "brand": "L'Or\u00e9al",
    "price": 24.18,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 17
  },
  {
    "name": "Studio Gold Eyeshadow Palette",
    "brand": "Huda Beauty",
    "price": 35.14,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 82
  },
  {
    "name": "Radiant Lilac Cleanser",
    "brand": "L'Or\u00e9al",
    "price": 53.14,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 89
  },
  {
    "name": "Feather Gold Primer",
    "brand": "Dior",
    "price": 31.43,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 42
  },
  {
    "name": "Velvet Coral Setting Powder",
    "brand": "The Ordinary",
    "price": 42.9,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 30
  },
  {
    "name": "Feather Berry Brow Gel",
    "brand": "Huda Beauty",
    "price": 43.58,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 68
  },
  {
    "name": "Pure Gold Primer",
    "brand": "NYX",
    "price": 27.2,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 55
  },
  {
    "name": "Air Taupe Setting Spray",
    "brand": "CeraVe",
    "price": 21.54,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 82
  },
  {
    "name": "Iconic Coral Lip Stain",
    "brand": "Kylie Cosmetics",
    "price": 48.1,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 39
  },
  {
    "name": "Ultra Plum Cream Shadow",
    "brand": "Fenty Beauty",
    "price": 42.91,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 102
  },
  {
    "name": "Glow Nude Exfoliant",
    "brand": "The Ordinary",
    "price": 23.36,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 66
  },
  {
    "name": "Matte Coral Eyeshadow Palette",
    "brand": "CeraVe",
    "price": 24.31,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 63
  },
  {
    "name": "Bloom Caramel Pore Filler",
    "brand": "L'Or\u00e9al",
    "price": 33.59,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 44
  },
  {
    "name": "Pure Cocoa Setting Powder",
    "brand": "Kylie Cosmetics",
    "price": 49.61,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 69
  },
  {
    "name": "Soft Taupe Exfoliant",
    "brand": "Clinique",
    "price": 58.26,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 112
  },
  {
    "name": "Luxe Plum Eyeshadow Palette",
    "brand": "Maybelline",
    "price": 35.43,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 68
  },
  {
    "name": "Luxe Pink Fixing Mist",
    "brand": "Rare Beauty",
    "price": 12.73,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 39
  },
  {
    "name": "Bloom Lilac Lip Crayon",
    "brand": "Rare Beauty",
    "price": 18.72,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 18
  },
  {
    "name": "Air Berry Brow Kit",
    "brand": "Kylie Cosmetics",
    "price": 13.17,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 15
  },
  {
    "name": "Glow Gold Setting Spray",
    "brand": "Dior",
    "price": 54.01,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 27
  },
  {
    "name": "Bloom Sunset Brow Gel",
    "brand": "Huda Beauty",
    "price": 46.33,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 29
  },
  {
    "name": "Pure Plum Tinted Moisturizer",
    "brand": "Est\u00e9e Lauder",
    "price": 8.72,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 57
  },
  {
    "name": "Soft Mocha Brow Gel",
    "brand": "Dior",
    "price": 58.98,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 57
  },
  {
    "name": "Luxe Bronze Single Shadow",
    "brand": "MAC",
    "price": 58.3,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 118
  },
  {
    "name": "Ultra Nude Foundation",
    "brand": "The Ordinary",
    "price": 48.69,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 41
  },
  {
    "name": "Bloom Sunset Primer",
    "brand": "Maybelline",
    "price": 18.44,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 39
  },
  {
    "name": "Iconic Plum Cleanser",
    "brand": "Clinique",
    "price": 52.49,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 28
  },
  {
    "name": "Radiant Rose Highlighter",
    "brand": "Charlotte Tilbury",
    "price": 13.98,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 55
  },
  {
    "name": "Radiant Nude Single Shadow",
    "brand": "MAC",
    "price": 13.71,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 63
  },
  {
    "name": "Hydra Ivory Tinted Moisturizer",
    "brand": "CeraVe",
    "price": 48.22,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 75
  },
  {
    "name": "Crystal Lilac BB Cream",
    "brand": "Dior",
    "price": 9.29,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 110
  },
  {
    "name": "Satin Rose Illuminator",
    "brand": "Charlotte Tilbury",
    "price": 10.21,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 71
  },
  {
    "name": "Glow Ivory Blush Duo",
    "brand": "The Ordinary",
    "price": 10.89,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 20
  },
  {
    "name": "Matte Lilac Serum",
    "brand": "Maybelline",
    "price": 40.54,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 80
  },
  {
    "name": "Iconic Coral Cream Shadow",
    "brand": "NYX",
    "price": 31.04,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 87
  },
  {
    "name": "Glow Berry BB Cream",
    "brand": "Clinique",
    "price": 30.92,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 39
  },
  {
    "name": "Satin Berry Single Shadow",
    "brand": "Est\u00e9e Lauder",
    "price": 45.66,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 50
  },
  {
    "name": "Pro Honey Single Shadow",
    "brand": "The Ordinary",
    "price": 43.39,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 70
  },
  {
    "name": "Hydra Berry Foundation",
    "brand": "Est\u00e9e Lauder",
    "price": 12.11,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 104
  },
  {
    "name": "Silky Espresso Toner",
    "brand": "NARS",
    "price": 36.76,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 95
  },
  {
    "name": "Studio Nude Cream Blush",
    "brand": "Huda Beauty",
    "price": 58.32,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 86
  },
  {
    "name": "Feather Bronze Cream Shadow",
    "brand": "Maybelline",
    "price": 15.19,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 71
  },
  {
    "name": "Bloom Mocha CC Cream",
    "brand": "Huda Beauty",
    "price": 47.41,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 83
  },
  {
    "name": "Bloom Lilac Cream Blush",
    "brand": "Est\u00e9e Lauder",
    "price": 42.76,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 81
  },
  {
    "name": "Radiant Coral Setting Powder",
    "brand": "MAC",
    "price": 55.83,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 54
  },
  {
    "name": "Matte Taupe Toner",
    "brand": "Est\u00e9e Lauder",
    "price": 10.68,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 104
  },
  {
    "name": "Crystal Taupe Liquid Lip",
    "brand": "Maybelline",
    "price": 29.24,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 53
  },
  {
    "name": "Cloud Lilac Cream Shadow",
    "brand": "Charlotte Tilbury",
    "price": 11.49,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 16
  },
  {
    "name": "Iconic Cherry Cleanser",
    "brand": "Clinique",
    "price": 21.41,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 94
  },
  {
    "name": "Satin Plum Brow Gel",
    "brand": "Rare Beauty",
    "price": 18.42,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 75
  },
  {
    "name": "Glow Sunset Single Shadow",
    "brand": "NYX",
    "price": 32.78,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 95
  },
  {
    "name": "Luxe Nude Lip Balm",
    "brand": "Fenty Beauty",
    "price": 7.4,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 48
  },
  {
    "name": "Pro Cocoa Serum",
    "brand": "Clinique",
    "price": 13.35,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 73
  },
  {
    "name": "Matte Espresso Blush Duo",
    "brand": "L'Or\u00e9al",
    "price": 44.28,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 74
  },
  {
    "name": "Luxe Nude Cream Shadow",
    "brand": "Maybelline",
    "price": 30.11,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 68
  },
  {
    "name": "Studio Taupe Cream Shadow",
    "brand": "Rare Beauty",
    "price": 44.59,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 63
  },
  {
    "name": "Velvet Pearl CC Cream",
    "brand": "NYX",
    "price": 49.46,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 89
  },
  {
    "name": "Studio Gold Eyeshadow Palette",
    "brand": "Maybelline",
    "price": 30.08,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 61
  },
  {
    "name": "Air Gold CC Cream",
    "brand": "NYX",
    "price": 24.64,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 31
  },
  {
    "name": "Glow Caramel Illuminator",
    "brand": "The Ordinary",
    "price": 17.27,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 109
  },
  {
    "name": "Matte Mocha Eyeshadow Palette",
    "brand": "CeraVe",
    "price": 14.75,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 35
  },
  {
    "name": "Hydra Sand Moisturizer",
    "brand": "Clinique",
    "price": 31.58,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 82
  },
  {
    "name": "Feather Lilac Brow Kit",
    "brand": "The Ordinary",
    "price": 24.12,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 90
  },
  {
    "name": "Hydra Ivory Sunscreen",
    "brand": "Dior",
    "price": 40.45,
    "category": "skincare",
    "description": "Targets dryness and supports a healthy barrier.",
    "image": "/assets/img/skincare.svg",
    "stock": 111
  },
  {
    "name": "Crystal Coral Lipstick",
    "brand": "Huda Beauty",
    "price": 31.46,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 14
  },
  {
    "name": "Air Cherry Eyeshadow Palette",
    "brand": "Est\u00e9e Lauder",
    "price": 39.59,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 74
  },
  {
    "name": "Bloom Nude Brow Kit",
    "brand": "Rare Beauty",
    "price": 30.83,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 113
  },
  {
    "name": "Iconic Caramel Pore Filler",
    "brand": "Huda Beauty",
    "price": 14.99,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 17
  },
  {
    "name": "Cloud Caramel Foundation",
    "brand": "Clinique",
    "price": 41.23,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 15
  },
  {
    "name": "Crystal Lilac Brow Kit",
    "brand": "Dior",
    "price": 15.4,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 57
  },
  {
    "name": "Cloud Lilac Cream Blush",
    "brand": "NYX",
    "price": 9.77,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 90
  },
  {
    "name": "Cloud Espresso Eyeshadow Palette",
    "brand": "Maybelline",
    "price": 42.94,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 46
  },
  {
    "name": "Hydra Honey Toner",
    "brand": "Huda Beauty",
    "price": 55.58,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 49
  },
  {
    "name": "Iconic Cherry Cream Blush",
    "brand": "L'Or\u00e9al",
    "price": 23.4,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 58
  },
  {
    "name": "Matte Caramel Cream Shadow",
    "brand": "Est\u00e9e Lauder",
    "price": 11.94,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 95
  },
  {
    "name": "Velvet Coral Glow Stick",
    "brand": "Huda Beauty",
    "price": 16.54,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 37
  },
  {
    "name": "Soft Honey Brow Pencil",
    "brand": "Fenty Beauty",
    "price": 11.08,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 118
  },
  {
    "name": "Bloom Caramel Illuminator",
    "brand": "Clinique",
    "price": 8.99,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 53
  },
  {
    "name": "Luxe Pearl Moisturizer",
    "brand": "Rare Beauty",
    "price": 16.57,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 98
  },
  {
    "name": "Satin Berry Cleanser",
    "brand": "CeraVe",
    "price": 26.3,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 102
  },
  {
    "name": "Air Ivory Brow Kit",
    "brand": "Rare Beauty",
    "price": 19.39,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 40
  },
  {
    "name": "Ultra Sunset Brow Gel",
    "brand": "Kylie Cosmetics",
    "price": 59.17,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 69
  },
  {
    "name": "Crystal Pearl Blush Duo",
    "brand": "NARS",
    "price": 50.29,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 112
  },
  {
    "name": "Pro Sand Cleanser",
    "brand": "Est\u00e9e Lauder",
    "price": 53.32,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 80
  },
  {
    "name": "Glow Cherry Glow Stick",
    "brand": "Est\u00e9e Lauder",
    "price": 47.44,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 44
  },
  {
    "name": "Studio Gold Highlighter",
    "brand": "L'Or\u00e9al",
    "price": 50.28,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 54
  },
  {
    "name": "Luxe Pink Cream Blush",
    "brand": "MAC",
    "price": 19.49,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 20
  },
  {
    "name": "Cloud Cocoa Primer",
    "brand": "MAC",
    "price": 48.93,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 27
  },
  {
    "name": "Pure Honey Fixing Mist",
    "brand": "Kylie Cosmetics",
    "price": 47.21,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 70
  },
  {
    "name": "Hydra Plum Lipstick",
    "brand": "Kylie Cosmetics",
    "price": 18.42,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 29
  },
  {
    "name": "Glow Gold Glow Stick",
    "brand": "NYX",
    "price": 22.95,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 16
  },
  {
    "name": "Iconic Cherry Blush Duo",
    "brand": "The Ordinary",
    "price": 12.87,
    "category": "blush",
    "description": "Natural-looking color that lasts.",
    "image": "/assets/img/blush.svg",
    "stock": 73
  },
  {
    "name": "Crystal Gold Illuminator",
    "brand": "MAC",
    "price": 45.07,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 47
  },
  {
    "name": "Dew Sunset Liquid Lip",
    "brand": "Rare Beauty",
    "price": 29.07,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 95
  },
  {
    "name": "Dew Caramel Foundation",
    "brand": "NARS",
    "price": 35.83,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 110
  },
  {
    "name": "Luxe Nude Glow Stick",
    "brand": "MAC",
    "price": 40.68,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 57
  },
  {
    "name": "Hydra Gold Lip Crayon",
    "brand": "Huda Beauty",
    "price": 45.84,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 90
  },
  {
    "name": "Silky Espresso Single Shadow",
    "brand": "L'Or\u00e9al",
    "price": 24.93,
    "category": "eyeshadow",
    "description": "Blendable pigments for endless looks.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 92
  },
  {
    "name": "Pure Pearl Brow Kit",
    "brand": "CeraVe",
    "price": 50.0,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 18
  },
  {
    "name": "Air Nude Brow Pencil",
    "brand": "MAC",
    "price": 48.92,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 15
  },
  {
    "name": "Luxe Sand Fixing Mist",
    "brand": "NARS",
    "price": 20.42,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 106
  },
  {
    "name": "Dew Cocoa Primer",
    "brand": "Charlotte Tilbury",
    "price": 21.47,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 112
  },
  {
    "name": "Luxe Ivory Cream Blush",
    "brand": "Kylie Cosmetics",
    "price": 54.41,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 59
  },
  {
    "name": "Pure Caramel Serum",
    "brand": "Dior",
    "price": 21.13,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 20
  },
  {
    "name": "Studio Pearl Cream Blush",
    "brand": "Maybelline",
    "price": 35.9,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 51
  },
  {
    "name": "Air Ivory CC Cream",
    "brand": "Huda Beauty",
    "price": 38.93,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 64
  },
  {
    "name": "Satin Pink Brow Pencil",
    "brand": "Huda Beauty",
    "price": 39.58,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 65
  },
  {
    "name": "Luxe Caramel Lip Crayon",
    "brand": "Maybelline",
    "price": 49.45,
    "category": "lipstick",
    "description": "Long-wear color with comfortable feel.",
    "image": "/assets/img/lipstick.svg",
    "stock": 96
  },
  {
    "name": "Iconic Nude Lip Stain",
    "brand": "L'Or\u00e9al",
    "price": 13.68,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 40
  },
  {
    "name": "Luxe Nude Cream Shadow",
    "brand": "Huda Beauty",
    "price": 39.06,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 96
  },
  {
    "name": "Satin Sunset Eyeshadow Palette",
    "brand": "Huda Beauty",
    "price": 14.29,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 56
  },
  {
    "name": "Pro Mocha Eyeshadow Palette",
    "brand": "The Ordinary",
    "price": 8.36,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 33
  },
  {
    "name": "Bloom Plum Highlighter",
    "brand": "NYX",
    "price": 48.06,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 100
  },
  {
    "name": "Air Sand Grip Primer",
    "brand": "Rare Beauty",
    "price": 17.6,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 27
  },
  {
    "name": "Satin Cocoa Brow Pencil",
    "brand": "L'Or\u00e9al",
    "price": 42.39,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 100
  },
  {
    "name": "Air Pearl Glow Stick",
    "brand": "NARS",
    "price": 44.72,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 99
  },
  {
    "name": "Dew Gold Toner",
    "brand": "Clinique",
    "price": 13.42,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 35
  },
  {
    "name": "Pure Pink Primer",
    "brand": "Clinique",
    "price": 36.35,
    "category": "primer",
    "description": "Blurs pores and grips foundation.",
    "image": "/assets/img/primer.svg",
    "stock": 57
  },
  {
    "name": "Iconic Cherry Highlighter",
    "brand": "L'Or\u00e9al",
    "price": 23.38,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 101
  },
  {
    "name": "Studio Sunset Brow Gel",
    "brand": "NARS",
    "price": 10.9,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 50
  },
  {
    "name": "Satin Honey CC Cream",
    "brand": "Dior",
    "price": 53.52,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 109
  },
  {
    "name": "Matte Caramel Sunscreen",
    "brand": "Clinique",
    "price": 55.26,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 17
  },
  {
    "name": "Air Pearl Highlighter",
    "brand": "L'Or\u00e9al",
    "price": 24.09,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 100
  },
  {
    "name": "Air Plum Eyeshadow Palette",
    "brand": "NARS",
    "price": 17.39,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 80
  },
  {
    "name": "Air Espresso Toner",
    "brand": "The Ordinary",
    "price": 11.94,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 92
  },
  {
    "name": "Iconic Lilac Exfoliant",
    "brand": "L'Or\u00e9al",
    "price": 24.88,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 82
  },
  {
    "name": "Silky Plum Lip Balm",
    "brand": "Maybelline",
    "price": 41.5,
    "category": "lipstick",
    "description": "Transfer-resistant formula with a soft finish.",
    "image": "/assets/img/lipstick.svg",
    "stock": 108
  },
  {
    "name": "Velvet Espresso Blush Duo",
    "brand": "Rare Beauty",
    "price": 22.34,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 48
  },
  {
    "name": "Luxe Ivory Pore Filler",
    "brand": "Clinique",
    "price": 10.86,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 17
  },
  {
    "name": "Pure Bronze Brow Gel",
    "brand": "NYX",
    "price": 25.02,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 28
  },
  {
    "name": "Dew Honey Single Shadow",
    "brand": "CeraVe",
    "price": 47.31,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 75
  },
  {
    "name": "Soft Mocha Tinted Moisturizer",
    "brand": "Huda Beauty",
    "price": 21.17,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 41
  },
  {
    "name": "Air Lilac Tinted Moisturizer",
    "brand": "MAC",
    "price": 29.15,
    "category": "foundation",
    "description": "Buildable coverage with a natural skin-like finish.",
    "image": "/assets/img/foundation.svg",
    "stock": 120
  },
  {
    "name": "Feather Cocoa Cream Shadow",
    "brand": "Kylie Cosmetics",
    "price": 17.05,
    "category": "eyeshadow",
    "description": "Rich color payoff with minimal fallout.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 30
  },
  {
    "name": "Pure Sand Glow Stick",
    "brand": "Dior",
    "price": 8.22,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 60
  },
  {
    "name": "Ultra Pink Brow Kit",
    "brand": "Fenty Beauty",
    "price": 9.57,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 46
  },
  {
    "name": "Bloom Mocha Brow Pencil",
    "brand": "Charlotte Tilbury",
    "price": 29.83,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 43
  },
  {
    "name": "Luxe Nude Single Shadow",
    "brand": "Clinique",
    "price": 28.22,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 82
  },
  {
    "name": "Bloom Cherry Pore Filler",
    "brand": "Huda Beauty",
    "price": 27.47,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 67
  },
  {
    "name": "Iconic Lilac Fixing Mist",
    "brand": "Est\u00e9e Lauder",
    "price": 13.29,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 22
  },
  {
    "name": "Cloud Pink Cream Shadow",
    "brand": "Clinique",
    "price": 47.0,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 35
  },
  {
    "name": "Crystal Nude Highlighter",
    "brand": "NYX",
    "price": 9.05,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 101
  },
  {
    "name": "Satin Lilac Brow Pencil",
    "brand": "NARS",
    "price": 54.33,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 27
  },
  {
    "name": "Luxe Coral Cream Shadow",
    "brand": "L'Or\u00e9al",
    "price": 38.46,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 74
  },
  {
    "name": "Feather Sand Glow Stick",
    "brand": "Dior",
    "price": 50.22,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 57
  },
  {
    "name": "Feather Rose CC Cream",
    "brand": "NYX",
    "price": 38.63,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 43
  },
  {
    "name": "Silky Sand Grip Primer",
    "brand": "CeraVe",
    "price": 16.03,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 90
  },
  {
    "name": "Soft Sunset Blush",
    "brand": "L'Or\u00e9al",
    "price": 57.24,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 24
  },
  {
    "name": "Cloud Honey Lip Stain",
    "brand": "Dior",
    "price": 28.88,
    "category": "lipstick",
    "description": "High pigment, smooth glide, all-day confidence.",
    "image": "/assets/img/lipstick.svg",
    "stock": 36
  },
  {
    "name": "Iconic Nude Glow Stick",
    "brand": "Clinique",
    "price": 44.4,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 76
  },
  {
    "name": "Pure Taupe Illuminator",
    "brand": "Huda Beauty",
    "price": 23.62,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 32
  },
  {
    "name": "Bloom Plum Glow Stick",
    "brand": "Huda Beauty",
    "price": 39.32,
    "category": "highlighter",
    "description": "Instant radiance with a lit-from-within glow.",
    "image": "/assets/img/highlighter.svg",
    "stock": 34
  },
  {
    "name": "Air Coral Setting Spray",
    "brand": "NARS",
    "price": 47.86,
    "category": "setting",
    "description": "Locks makeup in place with a soft-focus finish.",
    "image": "/assets/img/setting.svg",
    "stock": 100
  },
  {
    "name": "Pure Espresso Brow Gel",
    "brand": "Huda Beauty",
    "price": 56.48,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 111
  },
  {
    "name": "Glow Espresso Fixing Mist",
    "brand": "Charlotte Tilbury",
    "price": 27.11,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 60
  },
  {
    "name": "Silky Cherry Serum",
    "brand": "Charlotte Tilbury",
    "price": 25.35,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 66
  },
  {
    "name": "Pure Bronze Setting Spray",
    "brand": "CeraVe",
    "price": 50.87,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 44
  },
  {
    "name": "Glow Sunset Fixing Mist",
    "brand": "L'Or\u00e9al",
    "price": 19.67,
    "category": "setting",
    "description": "All-day hold with a breathable feel.",
    "image": "/assets/img/setting.svg",
    "stock": 16
  },
  {
    "name": "Soft Mocha Highlighter",
    "brand": "Fenty Beauty",
    "price": 28.89,
    "category": "highlighter",
    "description": "Buildable shine for subtle to bold.",
    "image": "/assets/img/highlighter.svg",
    "stock": 101
  },
  {
    "name": "Matte Espresso Foundation",
    "brand": "The Ordinary",
    "price": 58.82,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 30
  },
  {
    "name": "Ultra Cocoa Brow Gel",
    "brand": "Dior",
    "price": 22.12,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 17
  },
  {
    "name": "Silky Berry Primer",
    "brand": "NARS",
    "price": 53.75,
    "category": "primer",
    "description": "Smooths texture and helps makeup last longer.",
    "image": "/assets/img/primer.svg",
    "stock": 32
  },
  {
    "name": "Pure Coral Blush",
    "brand": "Clinique",
    "price": 53.46,
    "category": "blush",
    "description": "Silky texture that blends seamlessly.",
    "image": "/assets/img/blush.svg",
    "stock": 11
  },
  {
    "name": "Cloud Ivory CC Cream",
    "brand": "Kylie Cosmetics",
    "price": 59.41,
    "category": "foundation",
    "description": "Long-wear coverage that stays fresh.",
    "image": "/assets/img/foundation.svg",
    "stock": 79
  },
  {
    "name": "Matte Ivory Brow Kit",
    "brand": "Kylie Cosmetics",
    "price": 21.45,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 113
  },
  {
    "name": "Satin Plum Cream Shadow",
    "brand": "L'Or\u00e9al",
    "price": 45.08,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 11
  },
  {
    "name": "Air Bronze Cream Shadow",
    "brand": "Clinique",
    "price": 16.29,
    "category": "eyeshadow",
    "description": "Smooth, buildable shades for day to night.",
    "image": "/assets/img/eyeshadow.svg",
    "stock": 119
  },
  {
    "name": "Studio Cocoa Cream Blush",
    "brand": "Est\u00e9e Lauder",
    "price": 11.59,
    "category": "blush",
    "description": "Adds a fresh flush with buildable color.",
    "image": "/assets/img/blush.svg",
    "stock": 95
  },
  {
    "name": "Pure Gold Serum",
    "brand": "L'Or\u00e9al",
    "price": 7.35,
    "category": "skincare",
    "description": "Gentle care for everyday glow.",
    "image": "/assets/img/skincare.svg",
    "stock": 59
  },
  {
    "name": "Pro Coral Brow Gel",
    "brand": "Clinique",
    "price": 37.86,
    "category": "brows",
    "description": "Defines and shapes for polished brows.",
    "image": "/assets/img/brows.svg",
    "stock": 83
  },
  {
    "name": "Dew Gold Fixing Mist",
    "brand": "The Ordinary",
    "price": 10.28,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 25
  },
  {
    "name": "Luxe Caramel Fixing Mist",
    "brand": "L'Or\u00e9al",
    "price": 55.91,
    "category": "setting",
    "description": "Helps prevent creasing and fading.",
    "image": "/assets/img/setting.svg",
    "stock": 100
  },
  {
    "name": "Air Lilac CC Cream",
    "brand": "The Ordinary",
    "price": 18.7,
    "category": "foundation",
    "description": "Lightweight formula that blurs and evens tone.",
    "image": "/assets/img/foundation.svg",
    "stock": 27
  },
  {
    "name": "Iconic Berry Serum",
    "brand": "Dior",
    "price": 44.19,
    "category": "skincare",
    "description": "Clean, effective ingredients for balanced skin.",
    "image": "/assets/img/skincare.svg",
    "stock": 70
  },
  {
    "name": "Soft Lilac Grip Primer",
    "brand": "Clinique",
    "price": 53.27,
    "category": "primer",
    "description": "Weightless base for a flawless look.",
    "image": "/assets/img/primer.svg",
    "stock": 20
  },
  {
    "name": "Dew Sunset Brow Pencil",
    "brand": "NARS",
    "price": 12.94,
    "category": "brows",
    "description": "Easy precision for everyday definition.",
    "image": "/assets/img/brows.svg",
    "stock": 116
  },
  {
    "name": "Feather Honey Illuminator",
    "brand": "Fenty Beauty",
    "price": 15.71,
    "category": "highlighter",
    "description": "Smooth shimmer that melts into skin.",
    "image": "/assets/img/highlighter.svg",
    "stock": 119
  },
  {
    "name": "Ultra Sunset Brow Kit",
    "brand": "Maybelline",
    "price": 32.9,
    "category": "brows",
    "description": "Smudge-resistant control with natural finish.",
    "image": "/assets/img/brows.svg",
    "stock": 75
  }
];
