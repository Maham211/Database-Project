const fs = require("fs");
const path = require("path");

function loadEnvFile() {
  const p = path.join(process.cwd(), ".env");
  if (!fs.existsSync(p)) return;
  const raw = fs.readFileSync(p, "utf8");
  raw.split(/\r?\n/).forEach(line => {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (!m) return;
    const key = m[1];
    let val = m[2] ?? "";
    val = val.replace(/^['"]|['"]$/g, "");
    if (!process.env[key]) process.env[key] = val;
  });
}

module.exports = { loadEnvFile };
