# Makeup City Shop (Pure Node.js + MongoDB, No Express)

A small, **working** e-commerce demo built with:
- Frontend: HTML/CSS/JS (fetch API)
- Backend: **Node.js `http` module** (no Express)
- DB: MongoDB (native driver)
- Auth: bcrypt + JWT
- Admin: product CRUD + image upload (multipart/form-data)

## 1) Install prerequisites
- Node.js 18+ (recommended)
- MongoDB Community Server (running locally)

## 2) Setup
```bash
cd makeup-city-shop
npm install
```

Create `.env` (copy from `.env.example`) and edit values:
```bash
cp .env.example .env
```

## 3) Run
```bash
npm start
```

Open:
- Shop: http://localhost:3000
- Admin: http://localhost:3000/admin.html

## 4) First admin user
Register normally at `/register.html`, then in MongoDB set the user role to `admin`:

```js
use makeup_city_shop
db.users.updateOne({ email: "you@example.com" }, { $set: { role: "admin" } })
```

Then login again and open `/admin.html`.

## Notes
- Product images uploaded by admin are saved under `/uploads` and served at `/uploads/<filename>`.
- Cart is stored in `localStorage` (client side) as requested, and checkout creates an Order in MongoDB.
