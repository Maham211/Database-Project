const http = require("http");
const fs = require("fs");
const path = require("path");
const express = require("express");
const app = express();

const { loadEnvFile } = require("./src/env");
const { connect, getDb, oid } = require("./src/db");
const {
  sendJson, sendText, notFound, badRequest, serverError,
  getContentType, safeJoin, readBody, parseMultipart, getUrl
} = require("./src/http");
const { signToken, requireAuth, requireAdmin, hashPassword, verifyPassword } = require("./src/auth");

loadEnvFile();

const PORT = parseInt(process.env.PORT || "3000", 10);
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017";
const DB_NAME = process.env.DB_NAME || "makeup_city_shop";
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

const PUBLIC_DIR = path.join(__dirname, "public");
const UPLOAD_DIR = path.join(__dirname, "uploads");

// --- Minimal router ---
const routes = [];
function route(method, pattern, handler) {
  // pattern supports /api/products/:id
  const keys = [];
  const re = new RegExp("^" + pattern.replace(/\//g, "\\/").replace(/:([A-Za-z0-9_]+)/g, (_,k)=>{ keys.push(k); return "([^/]+)"; }) + "$");
  routes.push({ method, re, keys, handler });
}
function match(method, pathname) {
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = pathname.match(r.re);
    if (!m) continue;
    const params = {};
    r.keys.forEach((k, i) => params[k] = m[i+1]);
    return { handler: r.handler, params };
  }
  return null;
}

async function seedIfEmpty() {
  const db = getDb();
  const count = await db.collection("products").countDocuments();
  if (count > 0) return;
  const sample = require("./src/seed-products");
  await db.collection("products").insertMany(sample.map(p => ({
    ...p,
    createdAt: new Date(),
    updatedAt: new Date()
  })));
  console.log("Seeded sample products:", sample.length);
}

function sanitizeFilename(name) {
  return String(name || "file").replace(/[^a-z0-9._-]/gi, "_");
}

function serveStatic(req, res, pathname) {
  // uploads
  if (pathname.startsWith("/uploads/")) {
    const filePath = safeJoin(UPLOAD_DIR, pathname.replace("/uploads/", "/"));
    if (!filePath) return notFound(res);
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) return notFound(res);
    res.writeHead(200, { "Content-Type": getContentType(filePath) });
    fs.createReadStream(filePath).pipe(res);
    return true;
  }

  // public
  let reqPath = pathname === "/" ? "/index.html" : pathname;
  const filePath = safeJoin(PUBLIC_DIR, reqPath);
  if (!filePath) return false;

  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    res.writeHead(200, { "Content-Type": getContentType(filePath) });
    fs.createReadStream(filePath).pipe(res);
    return true;
  }
  return false;
}

// ---------- API ROUTES ----------

// Products listing
route("GET", "/api/products", async (req, res, params, url) => {
  const db = getDb();
  const q = (url.searchParams.get("q") || "").trim();
  const category = (url.searchParams.get("category") || "").trim();
  const brand = (url.searchParams.get("brand") || "").trim();
  const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get("limit") || "12", 10)));
  const skip = Math.max(0, parseInt(url.searchParams.get("skip") || "0", 10));

  const filter = {};
  if (category) filter.category = category;
  if (brand) filter.brand = brand;
  if (q) filter.$text = { $search: q };

  const cursor = db.collection("products")
    .find(filter)
    .project({ score: q ? { $meta: "textScore" } : 0 })
    .sort(q ? { score: { $meta: "textScore" } } : { createdAt: -1 })
    .skip(skip)
    .limit(limit);

  const items = await cursor.toArray();
  sendJson(res, 200, { items, skip, limit });
});

route("GET", "/api/products/:id", async (req, res, { id }) => {
  const db = getDb();
  const _id = oid(id);
  if (!_id) return badRequest(res, "Invalid product id");
  const item = await db.collection("products").findOne({ _id });
  if (!item) return sendJson(res, 404, { error: "Product not found" });
  sendJson(res, 200, item);
});

// Auth
route("POST", "/api/auth/register", async (req, res) => {
  const db = getDb();
  const bodyBuf = await readBody(req);
  let body;
  try { body = JSON.parse(bodyBuf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }

  const name = String(body.name || "").trim();
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  if (name.length < 2) return badRequest(res, "Name is too short");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return badRequest(res, "Invalid email");
  if (password.length < 6) return badRequest(res, "Password must be at least 6 characters");

  const user = {
    name,
    email,
    password: await hashPassword(password),
    role: "user",
    createdAt: new Date()
  };

  try {
    const r = await db.collection("users").insertOne(user);
    const saved = { _id: r.insertedId, name, email, role: user.role };
    const token = signToken(saved, JWT_SECRET);
    sendJson(res, 201, { token, user: saved });
  } catch (e) {
    if (String(e.message || "").includes("E11000")) return sendJson(res, 409, { error: "Email already exists" });
    throw e;
  }
});

route("POST", "/api/auth/login", async (req, res) => {
  const db = getDb();
  const bodyBuf = await readBody(req);
  let body;
  try { body = JSON.parse(bodyBuf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }

  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  const user = await db.collection("users").findOne({ email });
  if (!user) return sendJson(res, 401, { error: "Invalid credentials" });
  const ok = await verifyPassword(password, user.password);
  if (!ok) return sendJson(res, 401, { error: "Invalid credentials" });

  const safe = { _id: user._id, name: user.name, email: user.email, role: user.role || "user" };
  const token = signToken(safe, JWT_SECRET);
  sendJson(res, 200, { token, user: safe });
});

route("GET", "/api/me", async (req, res) => {
  const auth = requireAuth(JWT_SECRET);
  const ok = auth(req, res);
  if (!ok) return;
  sendJson(res, 200, { user: req.user });
});

// Orders
route("POST", "/api/orders", async (req, res) => {
  const auth = requireAuth(JWT_SECRET);
  const ok = auth(req, res);
  if (!ok) return;

  const db = getDb();
  const bodyBuf = await readBody(req);
  let body;
  try { body = JSON.parse(bodyBuf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }

  const items = Array.isArray(body.items) ? body.items : [];
  if (items.length === 0) return badRequest(res, "Cart is empty");

  // Fetch products and compute totals
  const prodIds = items.map(it => oid(it.productId)).filter(Boolean);
  const products = await db.collection("products").find({ _id: { $in: prodIds } }).toArray();
  const map = new Map(products.map(p => [String(p._id), p]));

  let totalPrice = 0;
  const cleanItems = [];
  for (const it of items) {
    const p = map.get(String(it.productId));
    if (!p) continue;
    const qty = Math.max(1, parseInt(it.quantity || 1, 10));
    const line = qty * Number(p.price || 0);
    totalPrice += line;
    cleanItems.push({ productId: p._id, quantity: qty, price: Number(p.price || 0), name: p.name });
  }
  if (cleanItems.length === 0) return badRequest(res, "No valid items");

  const order = {
    userId: oid(req.user.sub),
    items: cleanItems,
    totalPrice: Number(totalPrice.toFixed(2)),
    status: "placed",
    createdAt: new Date()
  };

  const r = await db.collection("orders").insertOne(order);
  sendJson(res, 201, { orderId: r.insertedId, ...order });
});

route("GET", "/api/orders", async (req, res) => {
  const auth = requireAuth(JWT_SECRET);
  const ok = auth(req, res);
  if (!ok) return;

  const db = getDb();
  const isAdmin = (req.user.role || "user") === "admin";
  const filter = isAdmin ? {} : { userId: oid(req.user.sub) };
  const items = await db.collection("orders").find(filter).sort({ createdAt: -1 }).limit(50).toArray();
  sendJson(res, 200, { items });
});

route("PUT", "/api/orders/:id", async (req, res, { id }) => {
  const admin = requireAdmin(JWT_SECRET);
  const ok = admin(req, res);
  if (!ok) return;

  const db = getDb();
  const _id = oid(id);
  if (!_id) return badRequest(res, "Invalid order id");
  const bodyBuf = await readBody(req);
  let body;
  try { body = JSON.parse(bodyBuf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }
  const status = String(body.status || "").trim();
  if (!status) return badRequest(res, "Missing status");
  await db.collection("orders").updateOne({ _id }, { $set: { status } });
  sendJson(res, 200, { ok: true });
});

// Admin product CRUD (JSON)
route("POST", "/api/admin/products", async (req, res) => {
  const admin = requireAdmin(JWT_SECRET);
  const ok = admin(req, res);
  if (!ok) return;

  const db = getDb();
  const ct = (req.headers["content-type"] || "");
  let product = {};

  if (ct.startsWith("multipart/form-data")) {
    const boundary = ct.split("boundary=")[1];
    if (!boundary) return badRequest(res, "Missing multipart boundary");
    const buf = await readBody(req, 10*1024*1024);
    const parsed = parseMultipart(buf, boundary);
    product = parsed.fields;

    if (parsed.files.length) {
      const f = parsed.files[0];
      const safe = Date.now() + "_" + sanitizeFilename(f.filename);
      const out = path.join(UPLOAD_DIR, safe);
      fs.writeFileSync(out, f.data);
      product.image = "/uploads/" + safe;
    }
  } else {
    const buf = await readBody(req);
    try { product = JSON.parse(buf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }
  }

  const doc = {
    name: String(product.name || "").trim(),
    brand: String(product.brand || "").trim(),
    price: Number(product.price || 0),
    category: String(product.category || "").trim(),
    description: String(product.description || "").trim(),
    image: String(product.image || "/assets/img/lipstick.svg"),
    stock: Math.max(0, parseInt(product.stock || 0, 10)),
    createdAt: new Date(),
    updatedAt: new Date()
  };
  if (!doc.name || !doc.category) return badRequest(res, "Missing name/category");
  const r = await db.collection("products").insertOne(doc);
  sendJson(res, 201, { _id: r.insertedId, ...doc });
});

route("PUT", "/api/admin/products/:id", async (req, res, { id }) => {
  const admin = requireAdmin(JWT_SECRET);
  const ok = admin(req, res);
  if (!ok) return;

  const db = getDb();
  const _id = oid(id);
  if (!_id) return badRequest(res, "Invalid product id");

  const ct = (req.headers["content-type"] || "");
  let update = {};

  if (ct.startsWith("multipart/form-data")) {
    const boundary = ct.split("boundary=")[1];
    if (!boundary) return badRequest(res, "Missing multipart boundary");
    const buf = await readBody(req, 10*1024*1024);
    const parsed = parseMultipart(buf, boundary);
    update = parsed.fields;

    if (parsed.files.length) {
      const f = parsed.files[0];
      const safe = Date.now() + "_" + sanitizeFilename(f.filename);
      const out = path.join(UPLOAD_DIR, safe);
      fs.writeFileSync(out, f.data);
      update.image = "/uploads/" + safe;
    }
  } else {
    const buf = await readBody(req);
    try { update = JSON.parse(buf.toString("utf8") || "{}"); } catch { return badRequest(res, "Invalid JSON"); }
  }

  const patch = {};
  ["name","brand","category","description","image"].forEach(k => {
    if (update[k] !== undefined) patch[k] = String(update[k]).trim();
  });
  if (update.price !== undefined) patch.price = Number(update.price || 0);
  if (update.stock !== undefined) patch.stock = Math.max(0, parseInt(update.stock || 0, 10));
  patch.updatedAt = new Date();

  await db.collection("products").updateOne({ _id }, { $set: patch });
  const item = await db.collection("products").findOne({ _id });
  sendJson(res, 200, item);
});

route("DELETE", "/api/admin/products/:id", async (req, res, { id }) => {
  const admin = requireAdmin(JWT_SECRET);
  const ok = admin(req, res);
  if (!ok) return;

  const db = getDb();
  const _id = oid(id);
  if (!_id) return badRequest(res, "Invalid product id");
  await db.collection("products").deleteOne({ _id });
  sendJson(res, 200, { ok: true });
});

// -------------- SERVER --------------
async function main() {
  await connect({ uri: MONGO_URI, dbName: DB_NAME });
  await seedIfEmpty();

  const server = http.createServer(async (req, res) => {
    try {
      const url = getUrl(req);
      const pathname = url.pathname;

      // API
      const m = match(req.method, pathname);
      if (m) {
        req.params = m.params;
        return await m.handler(req, res, m.params, url);
      }

      // Static
      if (serveStatic(req, res, pathname)) return;

      // Fallback SPA-ish pages
      return notFound(res);
    } catch (e) {
      if (String(e.message || "").includes("Payload too large")) return sendJson(res, 413, { error: "Payload too large" });
      return serverError(res, e);
    }
  });

  server.listen(PORT, () => {
    console.log(`✅ Makeup City Shop running: http://localhost:${PORT}`);
  });
}

main().catch(err => {
  console.error("Fatal startup error:", err);
  process.exit(1);
});
