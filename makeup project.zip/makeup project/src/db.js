const { MongoClient, ObjectId } = require("mongodb");

let client;
let db;

async function connect({ uri, dbName }) {
  if (db) return db;
  client = new MongoClient(uri);
  await client.connect();
  db = client.db(dbName);

  // Indexes
  await Promise.all([
    db.collection("users").createIndex({ email: 1 }, { unique: true }),
    db.collection("products").createIndex({ name: "text", brand: "text", category: "text" }),
    db.collection("orders").createIndex({ userId: 1, createdAt: -1 })
  ]);

  return db;
}

function getDb() {
  if (!db) throw new Error("DB not connected yet. Call connect() first.");
  return db;
}

function oid(id) {
  try { return new ObjectId(id); } catch { return null; }
}

async function close() {
  if (client) await client.close();
  client = null; db = null;
}

module.exports = { connect, getDb, oid, close };
