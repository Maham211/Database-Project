const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { unauthorized, forbidden } = require("./http");

function signToken(user, secret) {
  return jwt.sign(
    { sub: String(user._id), role: user.role || "user", name: user.name, email: user.email },
    secret,
    { expiresIn: "7d" }
  );
}

function verifyToken(token, secret) {
  return jwt.verify(token, secret);
}

function getBearer(req) {
  const h = req.headers["authorization"] || "";
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

function requireAuth(secret) {
  return (req, res) => {
    const token = getBearer(req);
    if (!token) return unauthorized(res, "Missing token");
    try {
      req.user = verifyToken(token, secret);
      return true;
    } catch (e) {
      return unauthorized(res, "Invalid token");
    }
  };
}

function requireAdmin(secret) {
  const auth = requireAuth(secret);
  return (req, res) => {
    const ok = auth(req, res);
    if (!ok) return false;
    if ((req.user?.role || "user") !== "admin") {
      forbidden(res, "Admin only");
      return false;
    }
    return true;
  };
}

async function hashPassword(pw) {
  return bcrypt.hash(pw, 10);
}

async function verifyPassword(pw, hash) {
  return bcrypt.compare(pw, hash);
}

module.exports = { signToken, verifyToken, requireAuth, requireAdmin, hashPassword, verifyPassword };
