const fs = require("fs");
const path = require("path");
const { URL } = require("url");

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function sendText(res, status, text, contentType="text/plain; charset=utf-8") {
  res.writeHead(status, { "Content-Type": contentType });
  res.end(text);
}

function notFound(res) {
  sendJson(res, 404, { error: "Not Found" });
}

function badRequest(res, msg="Bad Request") {
  sendJson(res, 400, { error: msg });
}

function unauthorized(res, msg="Unauthorized") {
  sendJson(res, 401, { error: msg });
}

function forbidden(res, msg="Forbidden") {
  sendJson(res, 403, { error: msg });
}

function serverError(res, err) {
  console.error(err);
  sendJson(res, 500, { error: "Server Error" });
}

function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const map = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".webp": "image/webp"
  };
  return map[ext] || "application/octet-stream";
}

function safeJoin(root, reqPath) {
  const decoded = decodeURIComponent(reqPath);
  const clean = decoded.replace(/\0/g, "").replace(/\.+/g, ".");
  const full = path.join(root, clean);
  const resolved = path.resolve(full);
  const resolvedRoot = path.resolve(root);
  if (!resolved.startsWith(resolvedRoot)) return null;
  return resolved;
}

async function readBody(req, limitBytes=2*1024*1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on("data", (c) => {
      total += c.length;
      if (total > limitBytes) {
        reject(new Error("Payload too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

// Basic multipart/form-data parser for single-file uploads
function parseMultipart(buffer, boundary) {
  const result = { fields: {}, files: [] };
  const b = Buffer.from("--" + boundary);
  let start = buffer.indexOf(b);
  while (start !== -1) {
    start += b.length;
    if (buffer[start] === 45 && buffer[start+1] === 45) break; // -- end
    // Skip CRLF
    if (buffer[start] === 13 && buffer[start+1] === 10) start += 2;

    const headerEnd = buffer.indexOf(Buffer.from("\r\n\r\n"), start);
    if (headerEnd === -1) break;
    const headerRaw = buffer.slice(start, headerEnd).toString("utf8");
    const headers = {};
    headerRaw.split(/\r\n/).forEach(line => {
      const idx = line.indexOf(":");
      if (idx > -1) headers[line.slice(0, idx).toLowerCase()] = line.slice(idx+1).trim();
    });

    const disp = headers["content-disposition"] || "";
    const nameMatch = disp.match(/name="([^"]+)"/);
    const fileMatch = disp.match(/filename="([^"]*)"/);
    const fieldName = nameMatch ? nameMatch[1] : null;

    let dataStart = headerEnd + 4;
    let next = buffer.indexOf(b, dataStart);
    if (next === -1) break;
    // remove trailing CRLF before boundary
    let dataEnd = next - 2;
    const data = buffer.slice(dataStart, dataEnd);

    if (fieldName) {
      if (fileMatch && fileMatch[1]) {
        result.files.push({
          field: fieldName,
          filename: fileMatch[1],
          contentType: headers["content-type"] || "application/octet-stream",
          data
        });
      } else {
        result.fields[fieldName] = data.toString("utf8");
      }
    }
    start = next;
  }
  return result;
}

function getUrl(req) {
  return new URL(req.url, "http://localhost");
}

module.exports = {
  sendJson, sendText, notFound, badRequest, unauthorized, forbidden, serverError,
  getContentType, safeJoin, readBody, parseMultipart, getUrl
};
