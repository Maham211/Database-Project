/* =========================================================
   MAKEUP CITY SHOP — app.js (Pure JS frontend)
   - No removals: keeps original behaviors + fixes missing flows
   - Adds: page transitions, full shop listing, product page, admin, auth
========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  // Page enter animation (no functional changes)
  requestAnimationFrame(() => document.body.classList.add("page-ready"));
document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("page-ready");
});

  /* =========================
     BASIC HELPERS
  ========================== */
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));

  const money = (n) => {
    const x = Number(n || 0);
    return "$" + x.toFixed(2);
  };

  function toast(msg) {
    let t = $("#toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "toast";
      document.body.appendChild(t);
    }
    t.textContent = String(msg);
    t.className = "show";
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(() => (t.className = ""), 2400);
  }

  
  // Expose toast helper for inline HTML handlers (e.g., onclick="MC.toast(...)")
  window.MC = window.MC || {};
  window.MC.toast = toast;
  window.toast = toast;

function qs(name) {
    return new URLSearchParams(location.search).get(name);
  }

  /* =========================
     GLOBAL MCUI OBJECT
  ========================== */
  window.MCUI = window.MCUI || {};

  /* =========================
     CART (LOCALSTORAGE)
  ========================== */
  const CART_KEY = "mc_cart";

  MCUI.cartGet = () => {
    try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
    catch { return []; }
  };

  MCUI.cartSet = (items) => {
    localStorage.setItem(CART_KEY, JSON.stringify(items || []));
    MCUI.updateCartCount();
  };

  MCUI.cartAdd = (product, qty = 1) => {
    const cart = MCUI.cartGet();
    const id = String(product._id || product.id || "");
    if (!id) return toast("Invalid product");
    const found = cart.find(x => x.productId === id);
    if (found) found.quantity += qty;
  else cart.push({
  productId: id,
  name: product.name,
  price: Number(product.price || 0),
  image: product.image,   // ⭐ NEW
  quantity: qty
});
    MCUI.cartSet(cart);
    toast("Added to cart");
  };

  MCUI.cartRemove = (productId) => {
    const cart = MCUI.cartGet().filter(x => x.productId !== String(productId));
    MCUI.cartSet(cart);
    MCUI.renderCart?.();
  };

  MCUI.cartClear = () => {
    MCUI.cartSet([]);
  };

  MCUI.updateCartCount = () => {
    const badge = $("#cartCount");
    if (!badge) return;
    const count = MCUI.cartGet().reduce((a, b) => a + (b.quantity || 0), 0);
    badge.textContent = String(count);
  };
MCUI.cartUpdateQty = (productId, qty) => {
  const cart = MCUI.cartGet();
  const item = cart.find(x => x.productId === String(productId));
  if (!item) return;

  item.quantity = Math.max(1, qty);
  MCUI.cartSet(cart);
  MCUI.renderCart();
};

  MCUI.updateCartCount();

  /* =========================
     AUTH + API
  ========================== */
  const TOKEN_KEY = "mc_token";

  async function api(url, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);
    const headers = options.headers ? { ...options.headers } : {};
    if (token) headers.Authorization = "Bearer " + token;

    const res = await fetch(url, { ...options, headers });

    // Try JSON always; fall back to text message
    let data = null;
    try { data = await res.json(); }
    catch { data = { message: await res.text() }; }

    if (!res.ok) throw new Error(data.message || "API error");
    return data;
  }

  async function refreshAccountUi() {
    const btn = $("#accountBtn");
    if (!btn) return;

    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) {
      btn.textContent = "Account";
      btn.href = "/login.html";
      return;
    }

    try {
      const me = await api("/api/me");
      btn.textContent = me?.user?.name ? me.user.name.split(" ")[0] : "Account";
      btn.href = "/thankyou.html"; // harmless; user can still use nav
      btn.onclick = (e) => {
        e.preventDefault();
        // simple menu via confirm to avoid adding more UI markup
        const yes = confirm("Log out?");
        if (yes) {
          localStorage.removeItem(TOKEN_KEY);
          toast("Logged out");
          refreshAccountUi();
        }
      };
    } catch {
      // token invalid
      localStorage.removeItem(TOKEN_KEY);
      btn.textContent = "Account";
      btn.href = "/login.html";
    }
  }

  refreshAccountUi();

  /* =========================
     GLOBAL SEARCH
  ========================== */
  const gForm = $("#globalSearchForm");
  if (gForm) {
    // keep default GET navigation; no JS needed
  }

  /* =========================
     PRODUCT CARD TEMPLATE
  ========================== */
  function productCard(p, idx = 0) {
    const id = String(p._id || "");
    return `
  <div class="card product product-card mc-anim"
       style="animation-delay:${idx * 35}ms"
       data-open="${id}">
       
    <div class="product-img">
      <img src="${p.image}" alt="${p.name}">
      <span class="arrow">➜</span>
    </div>

    <div class="name">${p.name}</div>
    <div class="price">${money(p.price)}</div>

    <div style="display:flex;gap:.5rem">
      <button class="btn pink" data-add="${id}">Add</button>
      <a class="btn" href="/product.html?id=${encodeURIComponent(id)}">View</a>
    </div>
  </div>
`;
  }

  function wireProductCardActions(rootEl, items) {
    $$("[data-add]", rootEl).forEach(btn => {
      btn.onclick = () => {
        const item = items.find(x => String(x._id) === String(btn.dataset.add));
        if (item) MCUI.cartAdd(item, 1);
      };
    });

    // click card to open details (except buttons/links)
    $$("[data-open]", rootEl).forEach(card => {
      card.onclick = (e) => {
        const tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : "";
        if (tag === "button" || tag === "a" || e.target?.closest("button") || e.target?.closest("a")) return;
        const id = card.dataset.open;
        if (id) location.href = "/product.html?id=" + encodeURIComponent(id);
      };
    });
  }

  /* =========================
     HOME PAGE (featuredGrid)
  ========================== */
  const featuredGrid = $("#featuredGrid");
  if (featuredGrid) {
    featuredGrid.innerHTML = `
      <div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>
    `;
    api("/api/products?limit=8")
      .then(data => {
        featuredGrid.innerHTML = data.items.map((p, i) => productCard(p, i)).join("");
        wireProductCardActions(featuredGrid, data.items);
      })
      .catch(e => featuredGrid.innerHTML = `<div class="card">${e.message}</div>`);
  }

  /* =========================
     PRODUCTS PAGE (products.html)
  ========================== */
  const productsGrid = $("#grid");
  const catEl = $("#category");
  const brandEl = $("#brand");
  const applyBtn = $("#apply");
  const clearBtn = $("#clear");

  if (productsGrid && (catEl || brandEl || applyBtn || clearBtn)) {
    // Inject Load More button if not present (no removals)
    let moreWrap = $("#moreWrap");
    if (!moreWrap) {
      moreWrap = document.createElement("div");
      moreWrap.id = "moreWrap";
      moreWrap.style.display = "flex";
      moreWrap.style.justifyContent = "center";
      moreWrap.style.marginTop = "1rem";
      moreWrap.innerHTML = `<button class="btn" id="loadMore">Load more</button>`;
      productsGrid.parentElement?.appendChild(moreWrap);
    }

    const loadMoreBtn = $("#loadMore");
    let state = { q: "", category: "", brand: "", skip: 0, limit: 24, done: false, items: [] };

    function readFiltersFromUrl() {
      const q = (qs("q") || "").trim();
      state.q = q;
      state.category = (qs("category") || "").trim();
      state.brand = (qs("brand") || "").trim();

      if ($("#globalSearchInput") && q) $("#globalSearchInput").value = q;
      if (catEl && state.category) catEl.value = state.category;
      if (brandEl && state.brand) brandEl.value = state.brand;
    }

    function setUrlFromFilters(resetSkip = true) {
      const url = new URL(location.href);
      const q = ($("#globalSearchInput")?.value || qs("q") || "").trim();
      const category = (catEl?.value || "").trim();
      const brand = (brandEl?.value || "").trim();

      if (q) url.searchParams.set("q", q); else url.searchParams.delete("q");
      if (category) url.searchParams.set("category", category); else url.searchParams.delete("category");
      if (brand) url.searchParams.set("brand", brand); else url.searchParams.delete("brand");

      history.replaceState({}, "", url.toString());

      state.q = q;
      state.category = category;
      state.brand = brand;
      if (resetSkip) { state.skip = 0; state.done = false; state.items = []; }
    }

    async function fetchPage() {
      const u = new URL("/api/products", location.origin);
      if (state.q) u.searchParams.set("q", state.q);
      if (state.category) u.searchParams.set("category", state.category);
      if (state.brand) u.searchParams.set("brand", state.brand);
      u.searchParams.set("limit", String(state.limit));
      u.searchParams.set("skip", String(state.skip));
      return api(u.pathname + u.search);
    }

    function render(reset = false) {
      if (reset) productsGrid.innerHTML = "";
      productsGrid.innerHTML = state.items.map((p, i) => productCard(p, i)).join("");
      wireProductCardActions(productsGrid, state.items);
      loadMoreBtn.disabled = state.done;
      loadMoreBtn.textContent = state.done ? "No more products" : "Load more";
    }

    async function loadNext(reset = false) {
      if (state.done) return;
      if (reset) {
        productsGrid.innerHTML = `
          <div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>
        `;
      }
      try {
        const data = await fetchPage();
        const page = data.items || [];
        if (reset) state.items = [];
        state.items = state.items.concat(page);
        state.skip += page.length;
        if (page.length < state.limit) state.done = true;
        render(true);
      } catch (e) {
        productsGrid.innerHTML = `<div class="card">${e.message}</div>`;
      }
    }

    readFiltersFromUrl();
    setUrlFromFilters(true);
    loadNext(true);

    applyBtn && (applyBtn.onclick = (e) => { e.preventDefault(); setUrlFromFilters(true); loadNext(true); });
    clearBtn && (clearBtn.onclick = (e) => {
      e.preventDefault();
      if ($("#globalSearchInput")) $("#globalSearchInput").value = "";
      if (catEl) catEl.value = "";
      if (brandEl) brandEl.value = "";
      setUrlFromFilters(true);
      loadNext(true);
    });

    loadMoreBtn && (loadMoreBtn.onclick = (e) => { e.preventDefault(); loadNext(false); });
  }

  /* =========================
     PRODUCT PAGE (product.html)
  ========================== */
  const wrap = $("#wrap");
  if (wrap && qs("id")) {
    const id = qs("id");
    wrap.innerHTML = `Loading…`;
    api("/api/products/" + encodeURIComponent(id))
      .then(p => {
        wrap.innerHTML = `
          <div style="display:grid;grid-template-columns: 1fr 1.2fr; gap:1rem; align-items:start">
            <div class="card" style="padding:1rem">
              <img src="${p.image}" alt="${p.name}" style="width:100%;height:260px;object-fit:contain">
            </div>
            <div>
              <h2 style="margin:.2rem 0">${p.name}</h2>
              <div style="color:var(--muted);margin-bottom:.5rem">${p.brand} • ${p.category}</div>
              <div style="font-size:1.6rem;font-weight:900;margin:.6rem 0">${money(p.price)}</div>
              <div style="line-height:1.6;margin:.8rem 0">${p.description || ""}</div>
              <div style="display:flex; gap:.6rem; align-items:center; flex-wrap:wrap">
                <input id="qty" class="input" type="number" min="1" value="1" style="max-width:120px">
                <button class="btn pink" id="addToCart">Add to cart</button>
                <a class="btn" href="/cart.html">Go to cart</a>
              </div>
              <div style="color:var(--muted);margin-top:.6rem">Stock: ${p.stock ?? "-"}</div>
            </div>
          </div>
        `;
        $("#addToCart").onclick = () => {
          const q = Math.max(1, parseInt($("#qty").value || "1", 10));
          MCUI.cartAdd(p, q);
        };
      })
      .catch(e => wrap.innerHTML = `<div class="card">${e.message}</div>`);
  }

 
/* =========================
   CART PAGE
========================== */
MCUI.renderCart = () => {
  const wrap = $("#cartItems");
  const totalEl = $("#grandTotal");
  const summary = document.querySelector("#summaryTotal");
  if (!wrap || !totalEl) return;

  const cart = MCUI.cartGet();
  if (!cart.length) {
    wrap.innerHTML = `<div class="card">Your cart is empty</div>`;
    totalEl.textContent = "$0.00";
    if (summary) summary.textContent = "$0.00";
    return;
  }

  let total = 0;
  wrap.innerHTML = cart.map((i, idx) => {
    const line = i.price * i.quantity;
    total += line;
    return `
      <div class="card cart-item mc-anim">
        <div class="cart-left">
          <img src="${i.image || '/images/placeholder.png'}" alt="${i.name}">
          <div class="cart-info">
            <strong>${i.name}</strong>
            <div class="cart-price">${money(i.price)}</div>
            <div class="qty">
              <button onclick="MCUI.qty('${i.productId}', -1)">−</button>
              <span>${i.quantity}</span>
              <button onclick="MCUI.qty('${i.productId}', 1)">+</button>
            </div>
          </div>
        </div>
        <button class="btn ghost" onclick="MCUI.cartRemove('${i.productId}')">Remove</button>
      </div>
    `;
  }).join("");

  totalEl.textContent = money(total);
  if (summary) summary.textContent = money(total);
};

MCUI.qty = (id, delta) => {
  const cart = MCUI.cartGet();
  const item = cart.find(x => x.productId === id);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) {
    MCUI.cartRemove(id);
    return;
  }
  MCUI.cartSet(cart);
  MCUI.renderCart();
};

MCUI.renderCart();


  /* =========================
     CHECKOUT PAGE
  ========================== */
  const placeBtn = $("#place");
  if (placeBtn) {
    placeBtn.onclick = async (e) => {
      e.preventDefault();
      const cart = MCUI.cartGet();
      if (!cart.length) return toast("Cart empty");

      placeBtn.disabled = true;
      placeBtn.textContent = "Placing…";

      try {
        await api("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            customer: {
              name: ($("#name")?.value || "").trim(),
              phone: ($("#phone")?.value || "").trim(),
              address: ($("#addr")?.value || "").trim(),
              payment: ($("#pay")?.value || "").trim(),
              promo: ($("#promo")?.value || "").trim(),
            },
            items: cart.map(i => ({ productId: i.productId, quantity: i.quantity, price: i.price }))
          })
        });
        MCUI.cartClear();
        toast("Order placed!");
        location.href = "/thankyou.html";
      } catch (err) {
        toast(err.message);
      } finally {
        placeBtn.disabled = false;
        placeBtn.textContent = "Place order";
      }
    };
  }
/* =========================
   HOME – TRENDING PRODUCTS
========================= */

const homeTrending = document.getElementById("homeTrending");

if (homeTrending) {
  homeTrending.innerHTML = `
    <div class="skeleton"></div>
    <div class="skeleton"></div>
    <div class="skeleton"></div>
    <div class="skeleton"></div>
  `;

  fetch("/api/products?limit=8")
    .then(res => res.json())
    .then(data => {
      if (!data.items || !data.items.length) {
        homeTrending.innerHTML = "<p>No trending products found</p>";
        return;
      }

      homeTrending.innerHTML = data.items.map(p => `
        <div class="card product product-card">
          <div class="product-img">
            <img src="${p.image}" alt="${p.name}">
            <span class="arrow">➜</span>
          </div>
          <div class="name">${p.name}</div>
          <div class="price">$${p.price}</div>
          <a class="btn pink" href="/product.html?id=${p._id}">View</a>
        </div>
      `).join("");
    })
    .catch(err => {
      homeTrending.innerHTML = "<p>Error loading products</p>";
      console.error(err);
    });
}

  /* =========================
     LOGIN PAGE
  ========================== */
  const loginBtn = $("#loginBtn");
  if (loginBtn) {
    loginBtn.onclick = async (e) => {
      e.preventDefault();
      const hint = $("#hint");
      hint && (hint.textContent = "");
      try {
        const res = await api("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: ($("#email")?.value || "").trim(),
            password: ($("#password")?.value || "")
          })
        });
        localStorage.setItem(TOKEN_KEY, res.token);
        toast("Logged in");
        await refreshAccountUi();
        location.href = "/products.html";
      } catch (err) {
        hint && (hint.textContent = err.message);
        toast(err.message);
      }
    };
  }
const grid = document.getElementById("productGrid");

if (grid) {
  grid.innerHTML = PRODUCTS.map(p => `
    <div class="card product-card">
      <img 
        src="${p.image}" 
        alt="${p.name}" 
        class="product-img"
        onerror="this.src='/assets/images/products/placeholder.png'"
      />

      <h3>${p.name}</h3>
      <p class="price">$${p.price}.00</p>

      <div class="actions">
        <button class="btn primary">Add</button>
        <a href="product.html?id=${p.id}" class="btn ghost">View</a>
      </div>
    </div>
  `).join("");
}

  /* =========================
     REGISTER PAGE
  ========================== */
  const regBtn = $("#regBtn");
  if (regBtn) {
    regBtn.onclick = async (e) => {
      e.preventDefault();
      const hint = $("#hint");
      hint && (hint.textContent = "");
      try {
        const res = await api("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: ($("#name")?.value || "").trim(),
            email: ($("#email")?.value || "").trim(),
            password: ($("#password")?.value || "")
          })
        });
        localStorage.setItem(TOKEN_KEY, res.token);
        toast("Account created");
        await refreshAccountUi();
        location.href = "/products.html";
      } catch (err) {
        hint && (hint.textContent = err.message);
        toast(err.message);
      }
    };
  }

window.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("page-ready");
});

});
